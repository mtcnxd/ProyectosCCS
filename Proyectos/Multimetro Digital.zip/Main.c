#include <G-PIC Lite!.c>
#include <SevenSegment.h>

float Lectura;
int Voltaje;
int Decenas, Unidades, Fraccion;

void main () 
{
   
   while (true)
   {
      Lectura = analogRead(0);
      Lectura = (Lectura*14/1023);
            
      Voltaje  =  (Lectura * 10);
      Decenas  =  ((Voltaje/100)%10);
      Unidades =  ((Voltaje/10)%10);
      Fraccion =  ( Voltaje%10 );
      
      for (int i=0; i<=25; i++)
      {
         DigitaNumero ( Fraccion, 0x01 );
         delay_ms (5);

         DigitaNumero ( Unidades, 0x02 );
         delay_ms (5);
         
         DigitaNumero ( Decenas, 0x04);
         delay_ms (5);
      }
   }
}

